insert into badge (name) values ('First Question');
insert into badge (name) values ('First Answer');
insert into badge (name) values ('First Comment on Question');
insert into badge (name) values ('First Comment on Answer');
insert into badge (name) values ('First 100 Questions');
insert into badge (name) values ('First 100 Answers');
